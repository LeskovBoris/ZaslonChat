package com.example.zaslonchat;

import android.preference.PreferenceFragment;

public class SettingsFragment extends PreferenceFragment {

}
